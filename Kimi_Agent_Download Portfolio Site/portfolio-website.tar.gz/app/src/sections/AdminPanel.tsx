import { useState } from 'react';
import { X, User, Briefcase, Code, FileText, Settings, RotateCcw, Plus, Trash2 } from 'lucide-react';
import { useAdmin } from '../context/AdminContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminPanel({ isOpen, onClose }: AdminPanelProps) {
  const { 
    data, 
    updateHero, 
    updateAbout, 
    updateContact,
    addProject,
    removeProject,
    addBlogPost,
    removeBlogPost,
    resetData 
  } = useAdmin();

  const [activeTab, setActiveTab] = useState('hero');
  const [newProject, setNewProject] = useState({ category: '', title: '', description: '', image: '' });
  const [newBlogPost, setNewBlogPost] = useState({ category: '', title: '', excerpt: '', image: '' });

  const handleAddProject = () => {
    if (newProject.title && newProject.description) {
      addProject({ ...newProject, link: '#' });
      setNewProject({ category: '', title: '', description: '', image: '' });
    }
  };

  const handleAddBlogPost = () => {
    if (newBlogPost.title && newBlogPost.excerpt) {
      addBlogPost({ ...newBlogPost, date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) });
      setNewBlogPost({ category: '', title: '', excerpt: '', image: '' });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[85vh] bg-[#0a0a0a] border-[#333] text-white p-0 overflow-hidden">
        <DialogHeader className="px-6 py-4 border-b border-[#222]">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-serif flex items-center gap-2">
              <Settings className="text-[#ff6b35]" size={20} />
              Admin Panel
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={resetData}
                className="border-[#333] text-gray-400 hover:text-white hover:border-[#ff6b35]"
              >
                <RotateCcw size={14} className="mr-1" />
                Reset
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                className="border-[#333] text-gray-400 hover:text-white hover:border-[#ff6b35]"
              >
                <X size={14} />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex h-[calc(85vh-80px)]">
          {/* Sidebar */}
          <TabsList className="flex-col h-full w-48 bg-[#111] border-r border-[#222] rounded-none p-2 space-y-1">
            <TabsTrigger 
              value="hero" 
              className="w-full justify-start gap-2 data-[state=active]:bg-[#ff6b35]/20 data-[state=active]:text-[#ff6b35]"
            >
              <User size={16} />
              Hero
            </TabsTrigger>
            <TabsTrigger 
              value="about"
              className="w-full justify-start gap-2 data-[state=active]:bg-[#ff6b35]/20 data-[state=active]:text-[#ff6b35]"
            >
              <Briefcase size={16} />
              About
            </TabsTrigger>
            <TabsTrigger 
              value="projects"
              className="w-full justify-start gap-2 data-[state=active]:bg-[#ff6b35]/20 data-[state=active]:text-[#ff6b35]"
            >
              <Code size={16} />
              Projects
            </TabsTrigger>
            <TabsTrigger 
              value="blog"
              className="w-full justify-start gap-2 data-[state=active]:bg-[#ff6b35]/20 data-[state=active]:text-[#ff6b35]"
            >
              <FileText size={16} />
              Blog
            </TabsTrigger>
            <TabsTrigger 
              value="contact"
              className="w-full justify-start gap-2 data-[state=active]:bg-[#ff6b35]/20 data-[state=active]:text-[#ff6b35]"
            >
              <Settings size={16} />
              Contact
            </TabsTrigger>
          </TabsList>

          {/* Content */}
          <ScrollArea className="flex-1 p-6">
            {/* Hero Tab */}
            <TabsContent value="hero" className="mt-0 space-y-4">
              <h3 className="text-lg font-semibold text-white mb-4">Hero Section</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-400">Greeting</Label>
                  <Input
                    value={data.hero.greeting}
                    onChange={(e) => updateHero({ greeting: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Name</Label>
                  <Input
                    value={data.hero.name}
                    onChange={(e) => updateHero({ name: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Title</Label>
                  <Input
                    value={data.hero.title}
                    onChange={(e) => updateHero({ title: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Description</Label>
                  <Textarea
                    value={data.hero.description}
                    onChange={(e) => updateHero({ description: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1 min-h-[100px]"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Profile Image URL</Label>
                  <Input
                    value={data.hero.profileImage}
                    onChange={(e) => updateHero({ profileImage: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
              </div>
            </TabsContent>

            {/* About Tab */}
            <TabsContent value="about" className="mt-0 space-y-4">
              <h3 className="text-lg font-semibold text-white mb-4">About Section</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-400">Description</Label>
                  <Textarea
                    value={data.about.description}
                    onChange={(e) => updateAbout({ description: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1 min-h-[120px]"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-400">Projects</Label>
                    <Input
                      type="number"
                      value={data.about.stats.projects}
                      onChange={(e) => updateAbout({ stats: { ...data.about.stats, projects: parseInt(e.target.value) || 0 } })}
                      className="bg-[#111] border-[#333] text-white mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Satisfaction %</Label>
                    <Input
                      type="number"
                      value={data.about.stats.satisfaction}
                      onChange={(e) => updateAbout({ stats: { ...data.about.stats, satisfaction: parseInt(e.target.value) || 0 } })}
                      className="bg-[#111] border-[#333] text-white mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Experience (years)</Label>
                    <Input
                      type="number"
                      value={data.about.stats.experience}
                      onChange={(e) => updateAbout({ stats: { ...data.about.stats, experience: parseInt(e.target.value) || 0 } })}
                      className="bg-[#111] border-[#333] text-white mt-1"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Projects Tab */}
            <TabsContent value="projects" className="mt-0 space-y-4">
              <h3 className="text-lg font-semibold text-white mb-4">Projects</h3>
              
              {/* Existing Projects */}
              <div className="space-y-3 mb-6">
                {data.projects.map((project) => (
                  <div key={project.id} className="flex items-center justify-between p-3 bg-[#111] border border-[#222] rounded-lg">
                    <div>
                      <div className="font-medium text-white">{project.title}</div>
                      <div className="text-sm text-gray-500">{project.category}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeProject(project.id)}
                      className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>

              {/* Add New Project */}
              <div className="p-4 bg-[#111] border border-[#222] rounded-lg space-y-3">
                <h4 className="text-sm font-medium text-gray-400">Add New Project</h4>
                <Input
                  placeholder="Category"
                  value={newProject.category}
                  onChange={(e) => setNewProject({ ...newProject, category: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Input
                  placeholder="Title"
                  value={newProject.title}
                  onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Textarea
                  placeholder="Description"
                  value={newProject.description}
                  onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Input
                  placeholder="Image URL"
                  value={newProject.image}
                  onChange={(e) => setNewProject({ ...newProject, image: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Button
                  onClick={handleAddProject}
                  className="w-full bg-[#ff6b35] hover:bg-[#ff8c5a] text-white"
                >
                  <Plus size={16} className="mr-1" />
                  Add Project
                </Button>
              </div>
            </TabsContent>

            {/* Blog Tab */}
            <TabsContent value="blog" className="mt-0 space-y-4">
              <h3 className="text-lg font-semibold text-white mb-4">Blog Posts</h3>
              
              {/* Existing Posts */}
              <div className="space-y-3 mb-6">
                {data.blogPosts.map((post) => (
                  <div key={post.id} className="flex items-center justify-between p-3 bg-[#111] border border-[#222] rounded-lg">
                    <div>
                      <div className="font-medium text-white">{post.title}</div>
                      <div className="text-sm text-gray-500">{post.category} • {post.date}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBlogPost(post.id)}
                      className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>

              {/* Add New Post */}
              <div className="p-4 bg-[#111] border border-[#222] rounded-lg space-y-3">
                <h4 className="text-sm font-medium text-gray-400">Add New Post</h4>
                <Input
                  placeholder="Category"
                  value={newBlogPost.category}
                  onChange={(e) => setNewBlogPost({ ...newBlogPost, category: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Input
                  placeholder="Title"
                  value={newBlogPost.title}
                  onChange={(e) => setNewBlogPost({ ...newBlogPost, title: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Textarea
                  placeholder="Excerpt"
                  value={newBlogPost.excerpt}
                  onChange={(e) => setNewBlogPost({ ...newBlogPost, excerpt: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Input
                  placeholder="Image URL"
                  value={newBlogPost.image}
                  onChange={(e) => setNewBlogPost({ ...newBlogPost, image: e.target.value })}
                  className="bg-[#0a0a0a] border-[#333] text-white"
                />
                <Button
                  onClick={handleAddBlogPost}
                  className="w-full bg-[#ff6b35] hover:bg-[#ff8c5a] text-white"
                >
                  <Plus size={16} className="mr-1" />
                  Add Post
                </Button>
              </div>
            </TabsContent>

            {/* Contact Tab */}
            <TabsContent value="contact" className="mt-0 space-y-4">
              <h3 className="text-lg font-semibold text-white mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-400">Email</Label>
                  <Input
                    value={data.contact.email}
                    onChange={(e) => updateContact({ email: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Phone</Label>
                  <Input
                    value={data.contact.phone}
                    onChange={(e) => updateContact({ phone: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Location</Label>
                  <Input
                    value={data.contact.location}
                    onChange={(e) => updateContact({ location: e.target.value })}
                    className="bg-[#111] border-[#333] text-white mt-1"
                  />
                </div>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
