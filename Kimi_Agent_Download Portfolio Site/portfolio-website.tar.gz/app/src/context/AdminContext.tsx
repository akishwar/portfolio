import React, { createContext, useContext, useState, useCallback } from 'react';

export interface Project {
  id: number;
  category: string;
  title: string;
  description: string;
  image: string;
  link?: string;
}

export interface BlogPost {
  id: number;
  category: string;
  title: string;
  excerpt: string;
  date: string;
  image: string;
}

export interface Skill {
  id: number;
  name: string;
  percentage: number;
  icon: string;
}

export interface Testimonial {
  id: number;
  quote: string;
  name: string;
  title: string;
  image?: string;
}

export interface PortfolioData {
  hero: {
    greeting: string;
    name: string;
    title: string;
    description: string;
    profileImage: string;
  };
  about: {
    description: string;
    stats: {
      projects: number;
      satisfaction: number;
      experience: number;
    };
  };
  projects: Project[];
  skills: Skill[];
  testimonials: Testimonial[];
  blogPosts: BlogPost[];
  contact: {
    email: string;
    phone: string;
    location: string;
  };
}

const defaultData: PortfolioData = {
  hero: {
    greeting: "Hello,",
    name: "I'm Jensen",
    title: "Software Developer",
    description: "I craft digital experiences that blend innovation with elegance. Every line of code is a step toward the extraordinary.",
    profileImage: "/hero-profile.jpg"
  },
  about: {
    description: "I'm a passionate software developer with over 10 years of experience creating digital solutions. My journey began with a curiosity for how things work, evolving into a career built on clean code and user-centered design.",
    stats: {
      projects: 120,
      satisfaction: 95,
      experience: 10
    }
  },
  projects: [
    {
      id: 1,
      category: "Web Application",
      title: "Financial Dashboard",
      description: "A comprehensive analytics platform for real-time financial data visualization and portfolio management.",
      image: "/project-1.jpg",
      link: "#"
    },
    {
      id: 2,
      category: "Web Development",
      title: "E-Commerce Platform",
      description: "Full-featured online store with seamless checkout and inventory management.",
      image: "/project-2.jpg",
      link: "#"
    },
    {
      id: 3,
      category: "Mobile App",
      title: "Health & Fitness App",
      description: "Cross-platform mobile application for tracking workouts and nutrition.",
      image: "/project-3.jpg",
      link: "#"
    },
    {
      id: 4,
      category: "Web Tool",
      title: "Portfolio Generator",
      description: "Dynamic portfolio creation tool for creatives and professionals.",
      image: "/project-4.jpg",
      link: "#"
    }
  ],
  skills: [
    { id: 1, name: "React", percentage: 95, icon: "⚛️" },
    { id: 2, name: "TypeScript", percentage: 90, icon: "📘" },
    { id: 3, name: "Node.js", percentage: 88, icon: "🟢" },
    { id: 4, name: "Python", percentage: 85, icon: "🐍" },
    { id: 5, name: "AWS", percentage: 82, icon: "☁️" },
    { id: 6, name: "GraphQL", percentage: 80, icon: "◈" },
    { id: 7, name: "Docker", percentage: 78, icon: "🐳" },
    { id: 8, name: "PostgreSQL", percentage: 85, icon: "🐘" }
  ],
  testimonials: [
    {
      id: 1,
      quote: "Jensen delivered exceptional work on our platform. His attention to detail and technical expertise transformed our vision into reality.",
      name: "Sarah Mitchell",
      title: "CEO, TechStart Inc."
    },
    {
      id: 2,
      quote: "Working with Jensen was a game-changer. He understood our needs perfectly and delivered beyond expectations.",
      name: "Michael Chen",
      title: "Product Manager, InnovateCo"
    },
    {
      id: 3,
      quote: "The best developer we've worked with. Fast, reliable, and incredibly skilled.",
      name: "Emily Rodriguez",
      title: "Founder, DesignStudio"
    }
  ],
  blogPosts: [
    {
      id: 1,
      category: "Development",
      title: "The Future of React in 2024",
      excerpt: "Exploring the latest features and patterns shaping modern React development.",
      date: "Dec 15, 2023",
      image: "/blog-1.jpg"
    },
    {
      id: 2,
      category: "Design",
      title: "Building Accessible Interfaces",
      excerpt: "A comprehensive guide to creating inclusive web experiences.",
      date: "Dec 10, 2023",
      image: "/blog-2.jpg"
    },
    {
      id: 3,
      category: "Technology",
      title: "Serverless Architecture Patterns",
      excerpt: "Best practices for building scalable serverless applications.",
      date: "Dec 5, 2023",
      image: "/blog-3.jpg"
    }
  ],
  contact: {
    email: "hello@jensenomega.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA"
  }
};

interface AdminContextType {
  data: PortfolioData;
  updateHero: (hero: Partial<PortfolioData['hero']>) => void;
  updateAbout: (about: Partial<PortfolioData['about']>) => void;
  updateProjects: (projects: Project[]) => void;
  updateSkills: (skills: Skill[]) => void;
  updateTestimonials: (testimonials: Testimonial[]) => void;
  updateBlogPosts: (blogPosts: BlogPost[]) => void;
  updateContact: (contact: Partial<PortfolioData['contact']>) => void;
  addProject: (project: Omit<Project, 'id'>) => void;
  removeProject: (id: number) => void;
  addBlogPost: (post: Omit<BlogPost, 'id'>) => void;
  removeBlogPost: (id: number) => void;
  resetData: () => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<PortfolioData>(() => {
    const saved = localStorage.getItem('portfolioData');
    return saved ? JSON.parse(saved) : defaultData;
  });

  const updateHero = useCallback((hero: Partial<PortfolioData['hero']>) => {
    setData(prev => {
      const newData = { ...prev, hero: { ...prev.hero, ...hero } };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateAbout = useCallback((about: Partial<PortfolioData['about']>) => {
    setData(prev => {
      const newData = { ...prev, about: { ...prev.about, ...about } };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateProjects = useCallback((projects: Project[]) => {
    setData(prev => {
      const newData = { ...prev, projects };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateSkills = useCallback((skills: Skill[]) => {
    setData(prev => {
      const newData = { ...prev, skills };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateTestimonials = useCallback((testimonials: Testimonial[]) => {
    setData(prev => {
      const newData = { ...prev, testimonials };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateBlogPosts = useCallback((blogPosts: BlogPost[]) => {
    setData(prev => {
      const newData = { ...prev, blogPosts };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const updateContact = useCallback((contact: Partial<PortfolioData['contact']>) => {
    setData(prev => {
      const newData = { ...prev, contact: { ...prev.contact, ...contact } };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const addProject = useCallback((project: Omit<Project, 'id'>) => {
    setData(prev => {
      const newProject = { ...project, id: Date.now() };
      const newData = { ...prev, projects: [...prev.projects, newProject] };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const removeProject = useCallback((id: number) => {
    setData(prev => {
      const newData = { ...prev, projects: prev.projects.filter(p => p.id !== id) };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const addBlogPost = useCallback((post: Omit<BlogPost, 'id'>) => {
    setData(prev => {
      const newPost = { ...post, id: Date.now() };
      const newData = { ...prev, blogPosts: [...prev.blogPosts, newPost] };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const removeBlogPost = useCallback((id: number) => {
    setData(prev => {
      const newData = { ...prev, blogPosts: prev.blogPosts.filter(p => p.id !== id) };
      localStorage.setItem('portfolioData', JSON.stringify(newData));
      return newData;
    });
  }, []);

  const resetData = useCallback(() => {
    setData(defaultData);
    localStorage.setItem('portfolioData', JSON.stringify(defaultData));
  }, []);

  return (
    <AdminContext.Provider value={{
      data,
      updateHero,
      updateAbout,
      updateProjects,
      updateSkills,
      updateTestimonials,
      updateBlogPosts,
      updateContact,
      addProject,
      removeProject,
      addBlogPost,
      removeBlogPost,
      resetData
    }}>
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
}
