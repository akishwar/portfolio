import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight, ExternalLink } from 'lucide-react';
import { useAdmin } from '../context/AdminContext';

gsap.registerPlugin(ScrollTrigger);

export default function Projects() {
  const { data } = useAdmin();
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title scramble effect simulation
      gsap.fromTo(titleRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none'
          }
        }
      );

      // Project cards stagger
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll('.project-card');
        gsap.fromTo(cards,
          { y: 80, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            stagger: 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="relative py-24 lg:py-32 bg-black overflow-hidden"
    >
      {/* Background particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[#ff6b35]/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${8 + Math.random() * 10}s`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[1920px] mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div ref={titleRef} className="text-center mb-16">
          <span className="text-sm text-[#ff6b35] uppercase tracking-widest mb-4 block">
            Portfolio
          </span>
          <h2 className="text-4xl lg:text-6xl font-serif font-bold text-white mb-4">
            Projects
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Selected works that showcase my expertise and passion for creating exceptional digital experiences.
          </p>
        </div>

        {/* Projects Grid */}
        <div ref={cardsRef} className="grid md:grid-cols-2 gap-8">
          {data.projects.map((project, index) => (
            <div
              key={project.id}
              className="project-card group relative bg-[#111] border border-[#222] rounded-2xl overflow-hidden
                hover:border-[#ff6b35]/30 transition-all duration-500
                hover:shadow-[0_20px_60px_rgba(255,107,53,0.15)]"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Image Container */}
              <div className="relative h-64 lg:h-80 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent 
                  opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

                {/* Category badge */}
                <div className="absolute top-4 left-4 px-3 py-1 bg-[#ff6b35]/20 border border-[#ff6b35]/30 
                  rounded-full text-xs text-[#ff6b35] font-medium backdrop-blur-sm
                  opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                  {project.category}
                </div>

                {/* View button */}
                <a
                  href={project.link || '#'}
                  className="absolute top-4 right-4 w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full
                    flex items-center justify-center text-white
                    opacity-0 group-hover:opacity-100 scale-0 group-hover:scale-100 rotate-45 group-hover:rotate-0
                    transition-all duration-300 hover:bg-[#ff6b35]"
                >
                  <ArrowUpRight size={18} />
                </a>
              </div>

              {/* Content */}
              <div className="p-6 lg:p-8">
                <h3 className="text-xl lg:text-2xl font-serif font-bold text-white mb-3 
                  group-hover:text-[#ff6b35] transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-gray-400 text-sm lg:text-base leading-relaxed mb-4">
                  {project.description}
                </p>
                
                {/* View Project Link */}
                <a
                  href={project.link || '#'}
                  className="inline-flex items-center gap-2 text-sm text-[#ff6b35] font-medium
                    group/link hover:gap-3 transition-all duration-300"
                >
                  View Project
                  <ExternalLink size={14} className="group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>

              {/* Border glow effect */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{
                  background: 'linear-gradient(135deg, rgba(255,107,53,0.1) 0%, transparent 50%, rgba(255,107,53,0.1) 100%)'
                }}
              />
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="px-8 py-3.5 border border-[#333] text-white rounded-full font-medium
            hover:border-[#ff6b35] hover:text-[#ff6b35] hover:bg-[#ff6b35]/10
            transition-all duration-300 flex items-center gap-2 mx-auto group">
            View All Projects
            <ArrowUpRight size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
