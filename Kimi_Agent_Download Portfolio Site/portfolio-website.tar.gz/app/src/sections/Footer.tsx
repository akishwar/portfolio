import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Twitter, Linkedin, Github, Dribbble, ArrowUpRight } from 'lucide-react';
import { useAdmin } from '../context/AdminContext';

gsap.registerPlugin(ScrollTrigger);

const quickLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Projects', href: '#projects' },
  { name: 'Blog', href: '#blog' },
  { name: 'Contact', href: '#contact' }
];

const services = [
  'Web Development',
  'App Development',
  'UI/UX Design',
  'Cloud Solutions'
];

const socialLinks = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Dribbble, href: '#', label: 'Dribbble' }
];

export default function Footer() {
  const { data } = useAdmin();
  const footerRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (contentRef.current) {
        const columns = contentRef.current.querySelectorAll('.footer-column');
        gsap.fromTo(columns,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: footerRef.current,
              start: 'top 90%',
              toggleActions: 'play none none none'
            }
          }
        );
      }
    }, footerRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer
      id="contact"
      ref={footerRef}
      className="relative py-16 lg:py-24 bg-[#0a0a0a] border-t border-[#222] overflow-hidden"
    >
      {/* Background watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
        <span className="text-[20vw] font-serif font-bold text-white/[0.02] select-none">
          JΩ
        </span>
      </div>

      <div className="relative z-10 max-w-[1920px] mx-auto px-6 lg:px-12">
        <div ref={contentRef} className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          {/* Brand Column */}
          <div className="footer-column lg:col-span-1">
            <a href="#home" className="inline-block text-2xl font-serif font-bold text-white mb-4">
              Jensen<span className="text-[#ff6b35]">Omega</span>
            </a>
            <p className="text-gray-500 mb-6 leading-relaxed">
              Crafting digital experiences that inspire and innovate.
            </p>
            {/* Social Icons */}
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full bg-[#222] border border-[#333] 
                    flex items-center justify-center text-gray-400
                    hover:bg-[#ff6b35]/10 hover:border-[#ff6b35]/50 hover:text-[#ff6b35] hover:scale-110
                    transition-all duration-300"
                >
                  <social.icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="footer-column">
            <h3 className="text-white font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                    className="text-gray-500 hover:text-[#ff6b35] hover:translate-x-1 
                      inline-flex items-center gap-1 transition-all duration-200 group"
                  >
                    {link.name}
                    <ArrowUpRight size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className="footer-column">
            <h3 className="text-white font-semibold mb-6">Services</h3>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <span className="text-gray-500 hover:text-[#ff6b35] transition-colors duration-200 cursor-pointer">
                    {service}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="footer-column">
            <h3 className="text-white font-semibold mb-6">Get in Touch</h3>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-600 mb-1">Email</div>
                <a 
                  href={`mailto:${data.contact.email}`}
                  className="text-gray-400 hover:text-[#ff6b35] transition-colors"
                >
                  {data.contact.email}
                </a>
              </div>
              <div>
                <div className="text-sm text-gray-600 mb-1">Phone</div>
                <a 
                  href={`tel:${data.contact.phone}`}
                  className="text-gray-400 hover:text-[#ff6b35] transition-colors"
                >
                  {data.contact.phone}
                </a>
              </div>
              <div>
                <div className="text-sm text-gray-600 mb-1">Location</div>
                <span className="text-gray-400">{data.contact.location}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#222] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-sm">
            © {new Date().getFullYear()} Jensen Omega. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-gray-600 hover:text-[#ff6b35] transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-600 hover:text-[#ff6b35] transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
