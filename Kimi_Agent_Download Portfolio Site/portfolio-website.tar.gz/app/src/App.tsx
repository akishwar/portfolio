import { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import ClientLogos from './sections/ClientLogos';
import About from './sections/About';
import Projects from './sections/Projects';
import Skills from './sections/Skills';
import Testimonials from './sections/Testimonials';
import Blog from './sections/Blog';
import CTA from './sections/CTA';
import Footer from './sections/Footer';
import AdminPanel from './sections/AdminPanel';
import { AdminProvider } from './context/AdminContext';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Initialize scroll animations
    const ctx = gsap.context(() => {
      // Refresh ScrollTrigger on load
      ScrollTrigger.refresh();
    }, mainRef);

    return () => ctx.revert();
  }, []);

  // Admin panel keyboard shortcut (Ctrl + Shift + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        setIsAdminOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <AdminProvider>
      <div ref={mainRef} className="min-h-screen bg-black text-white overflow-x-hidden">
        <Navigation scrolled={scrolled} onAdminClick={() => setIsAdminOpen(true)} />
        
        <main>
          <Hero />
          <ClientLogos />
          <About />
          <Projects />
          <Skills />
          <Testimonials />
          <Blog />
          <CTA />
        </main>
        
        <Footer />
        
        <AdminPanel isOpen={isAdminOpen} onClose={() => setIsAdminOpen(false)} />
        
        {/* Admin hint - shows briefly on load */}
        <AdminHint />
      </div>
    </AdminProvider>
  );
}

function AdminHint() {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 5000);
    return () => clearTimeout(timer);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-black/90 border border-[#ff6b35]/30 rounded-lg px-4 py-2 text-xs text-gray-400 animate-fade-out">
      Press <kbd className="bg-gray-800 px-1 rounded">Ctrl</kbd> + <kbd className="bg-gray-800 px-1 rounded">Shift</kbd> + <kbd className="bg-gray-800 px-1 rounded">A</kbd> for Admin
    </div>
  );
}

export default App;
